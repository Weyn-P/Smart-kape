<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config.php';

// Security check
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

if ($_SESSION['role'] === 'Staff') {
    header("Location: dashboard.php");
    exit();
}

$user = htmlspecialchars($_SESSION['username']);
$role = htmlspecialchars($_SESSION['role']);

// Determine Filter Period
$period = $_GET['period'] ?? 'today';
$today = date('Y-m-d');

if ($period === 'yesterday') {
    $date_from = date('Y-m-d', strtotime('-1 day'));
    $date_to = date('Y-m-d', strtotime('-1 day'));
    $period_label = "Yesterday (" . date('F d, Y', strtotime('-1 day')) . ")";
} elseif ($period === 'week') {
    $date_from = date('Y-m-d', strtotime('-6 days'));
    $date_to = $today;
    $period_label = "Last 7 Days (" . date('M d', strtotime('-6 days')) . " - " . date('M d, Y') . ")";
} elseif ($period === 'month') {
    $date_from = date('Y-m-01');
    $date_to = date('Y-m-t');
    $period_label = "Month-to-Date (" . date('F Y') . ")";
} elseif ($period === 'all') {
    $date_from = '2020-01-01';
    $date_to = $today;
    $period_label = "All Time Records";
} elseif ($period === 'custom' && !empty($_GET['date_from']) && !empty($_GET['date_to'])) {
    $date_from = $_GET['date_from'];
    $date_to = $_GET['date_to'];
    $period_label = "Custom Period (" . date('M d, Y', strtotime($date_from)) . " to " . date('M d, Y', strtotime($date_to)) . ")";
} else {
    // Default Today
    $period = 'today';
    $date_from = $today;
    $date_to = $today;
    $period_label = "Today (" . date('F d, Y') . ")";
}

$default_shift_date = ($date_from === $date_to) ? $date_from : date('Y-m-d');
$default_cashier = $user;

// Fetch Itemized Transactions for Period
$transactions_sql = "SELECT 
    o.id AS transaction_id,
    o.queue_number,
    o.order_date,
    o.staff_username,
    COALESCE(oi.menu_item_name, 'Special Order') AS item_description,
    COALESCE(oi.quantity, 1) AS qty,
    COALESCE(oi.price, o.total_amount) AS unit_price,
    COALESCE(oi.quantity * oi.price, o.total_amount) AS line_total
FROM orders o
LEFT JOIN order_items oi ON oi.order_id = o.id
WHERE DATE(o.order_date) BETWEEN '$date_from' AND '$date_to' 
  AND LOWER(TRIM(o.order_status)) = 'completed'
ORDER BY o.order_date DESC, o.id DESC, oi.id ASC";

$trans_res = mysqli_query($conn, $transactions_sql);
$transactions = [];
$total_qty = 0;
$grand_total = 0.00;

if ($trans_res) {
    while ($row = mysqli_fetch_assoc($trans_res)) {
        $lt = (float)$row['line_total'];
        $total_qty += (int)$row['qty'];
        $grand_total += $lt;
        $transactions[] = $row;
    }
}

// Financial VAT & Net Sales (matching 12% Philippine VAT standard in the example PDF)
$net_sales = round($grand_total / 1.12, 2);
$vat_12 = round($grand_total - $net_sales, 2);

// Date formatting for the header
$record_date_display = date('F d, Y', strtotime($date_to));
$log_id = "DSR-" . date('Y-md', strtotime($date_to));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BesKape Coffee Roasters - Daily Sales Record</title>
    
    <!-- Formal Serif & Sans Typography -->
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- html2pdf.js for High-Resolution PDF Download (Stable CDN) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js"></script>

    <style>
        /* ==========================================================================
           BesKape Coffee Roasters - Daily Sales Record (Formal Reference Format)
           ========================================================================== */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Times New Roman', Times, 'Libre Baskerville', Georgia, serif;
            background: #eef2f6;
            color: #000000;
            padding: 24px 14px;
            min-height: 100vh;
            line-height: 1.35;
            -webkit-font-smoothing: antialiased;
        }

        /* --------------------------------------------------------------------------
           Action Bar (On-screen only; hidden during Print and PDF Export)
           -------------------------------------------------------------------------- */
        .action-bar {
            max-width: 800px;
            margin: 0 auto 20px auto;
            background: #ffffff;
            padding: 14px 20px;
            border-radius: 8px;
            border: 1px solid #cbd5e1;
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.06);
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            justify-content: space-between;
            align-items: center;
            font-family: 'Inter', sans-serif;
        }

        .filter-group {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }

        .period-pill {
            padding: 5px 12px;
            border-radius: 4px;
            font-size: 11.5px;
            font-weight: 600;
            text-decoration: none;
            color: #1e293b;
            background: #f1f5f9;
            border: 1px solid #cbd5e1;
            transition: all 0.15s ease;
        }

        .period-pill:hover,
        .period-pill.active {
            background: #000000;
            color: #ffffff;
            border-color: #000000;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-action {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 14px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
            border: 1px solid #000000;
            background: #ffffff;
            color: #000000;
            transition: all 0.15s ease;
        }

        .btn-action:hover {
            background: #f4f4f4;
        }

        .btn-action.btn-dark {
            background: #000000;
            color: #ffffff;
        }

        .btn-action.btn-dark:hover {
            background: #222222;
        }

        .custom-filter-form {
            max-width: 800px;
            margin: -10px auto 20px auto;
            background: #ffffff;
            padding: 10px 18px;
            border-radius: 6px;
            border: 1px solid #cbd5e1;
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            font-family: 'Inter', sans-serif;
            font-size: 12px;
        }

        .custom-filter-form input[type="date"] {
            padding: 4px 8px;
            border: 1px solid #cbd5e1;
            border-radius: 4px;
            font-size: 12px;
        }

        .btn-filter-apply {
            padding: 4px 12px;
            background: #000000;
            color: #ffffff;
            border: none;
            border-radius: 4px;
            font-size: 11.5px;
            font-weight: 700;
            cursor: pointer;
        }

        /* --------------------------------------------------------------------------
           Document Sheet (Matches Formal Reference PDF from format folder)
           -------------------------------------------------------------------------- */
        .record-sheet {
            width: 100%;
            max-width: 780px;
            margin: 0 auto;
            background: #ffffff;
            color: #000000;
            padding: 24px 28px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            box-sizing: border-box;
        }

        /* Running Top Header */
        .running-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 9px;
            color: #111111;
            padding-bottom: 4px;
            border-bottom: 0.8px solid #000000;
            margin-bottom: 16px;
            letter-spacing: 0.2px;
            width: 100%;
        }

        /* Main Header: 2 Columns */
        .doc-header-grid {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 8px;
            width: 100%;
            page-break-inside: avoid;
        }

        .header-left {
            flex: 1;
        }

        .brand-title {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: 0.5px;
            line-height: 1.08;
            text-transform: uppercase;
            color: #000000;
        }

        .brand-division {
            font-size: 10.5px;
            font-weight: 600;
            color: #111111;
            margin-top: 4px;
            margin-bottom: 1px;
        }

        .brand-address {
            font-size: 9.5px;
            color: #222222;
            line-height: 1.35;
        }

        .brand-tax-contact {
            font-size: 9.5px;
            color: #222222;
            line-height: 1.35;
        }

        .header-right {
            text-align: right;
            min-width: 180px;
        }

        .doc-main-title {
            font-size: 20px;
            font-weight: 800;
            letter-spacing: 0.5px;
            line-height: 1.08;
            text-transform: uppercase;
            color: #000000;
        }

        .meta-field {
            font-size: 10.5px;
            color: #000000;
            line-height: 1.45;
        }

        .meta-field.first {
            margin-top: 5px;
        }

        .meta-label {
            font-weight: 700;
        }

        /* Solid Header Divider Line */
        .header-divider-line {
            border-bottom: 2px solid #000000;
            margin-top: 8px;
            margin-bottom: 12px;
            width: 100%;
        }

        /* Shift & Cashier Box */
        .shift-box {
            border: 1px solid #000000;
            padding: 7px 10px;
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 10px;
            background: #ffffff;
            width: 100%;
            box-sizing: border-box;
            page-break-inside: avoid;
        }

        .shift-col {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .shift-label {
            font-weight: 700;
        }

        .shift-fill-line {
            border-bottom: 1px solid #000000;
            min-width: 80px;
            max-width: 140px;
            display: inline-block;
            padding: 0 4px;
            font-size: 10px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .shift-editable-input {
            border: none;
            border-bottom: 1px solid #000000;
            background: transparent;
            font-family: inherit;
            font-size: 10px;
            font-weight: 700;
            color: #000000;
            padding: 1px 4px;
            width: 115px;
            outline: none;
            border-radius: 0;
            transition: background 0.15s ease, border-color 0.15s ease;
        }

        .shift-editable-input:hover {
            background: #f1f5f9;
        }

        .shift-editable-input:focus {
            background: #fef08a;
            border-bottom: 1.5px solid #000000;
        }

        .shift-editable-input.float-width {
            width: 75px;
            text-align: right;
        }

        .edit-hint-icon {
            font-size: 8px;
            color: #94a3b8;
            margin-left: 2px;
            cursor: pointer;
        }

        .print-val {
            display: none;
        }

        .shift-check-group {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .shift-check-box {
            display: inline-flex;
            align-items: center;
            gap: 3px;
            cursor: pointer;
            user-select: none;
        }

        .shift-check-square {
            display: inline-block;
            width: 11px;
            height: 11px;
            border: 1px solid #000000;
            vertical-align: middle;
            text-align: center;
            line-height: 9px;
            font-size: 9px;
            font-weight: 700;
        }

        /* Transaction Table */
        .transaction-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 10px;
            color: #000000;
            margin-bottom: 16px;
            table-layout: fixed;
            box-sizing: border-box;
        }

        .transaction-table thead {
            border-top: 2px solid #000000;
            border-bottom: 1.5px solid #000000;
        }

        .transaction-table th {
            padding: 5px 3px;
            font-weight: 700;
            text-transform: uppercase;
            font-size: 9px;
            letter-spacing: 0.2px;
            background: #ffffff;
            color: #000000;
            vertical-align: middle;
            line-height: 1.15;
            box-sizing: border-box;
        }

        .transaction-table tbody tr {
            border-bottom: 0.5px solid #d4d4d4;
        }

        .transaction-table td {
            padding: 4px 3px;
            vertical-align: middle;
            color: #000000;
            line-height: 1.25;
            word-wrap: break-word;
            overflow: hidden;
            box-sizing: border-box;
        }

        .col-datetime { width: 15%; text-align: left; }
        .col-transno { width: 14%; text-align: left; }
        .col-desc { width: 31%; text-align: left; }
        .col-qty { width: 6%; text-align: center; }
        .col-unitprice { width: 11%; text-align: right; }
        .col-method { width: 11%; text-align: left; padding-left: 4px; }
        .col-grandtotal { width: 12%; text-align: right; }

        .empty-table-cell {
            padding: 20px !important;
            text-align: center;
            font-style: italic;
            color: #444444;
        }

        /* Two-Column Reconciliation & Summary Section */
        .reconciliation-summary-grid {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 18px;
            gap: 16px;
            width: 100%;
            box-sizing: border-box;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
        }

        /* Left: Payment Method Reconciliation Box */
        .payment-recon-box {
            flex: 1;
            max-width: 340px;
            border: 1px solid #000000;
            padding: 8px 10px;
            background: #ffffff;
            box-sizing: border-box;
        }

        .payment-recon-title {
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            border-bottom: 1px solid #000000;
            padding-bottom: 3px;
            margin-bottom: 6px;
        }

        .recon-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 10px;
            padding: 2px 0;
        }

        .recon-amount {
            font-weight: 700;
            font-size: 10px;
        }

        /* Right: Financial Summary Totals */
        .summary-totals-block {
            width: 290px;
            margin-left: auto;
            box-sizing: border-box;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 10.5px;
            padding: 2.5px 0;
        }

        .summary-row-bold {
            font-weight: 700;
        }

        .summary-rule {
            border-top: 1px solid #000000;
            margin: 4px 0;
        }

        .revenue-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 12px;
            font-weight: 800;
            padding: 3px 0;
            border-bottom: 3px double #000000;
        }

        /* Sign-off Handover Footer */
        .signoff-section {
            border-top: 1.5px solid #000000;
            padding-top: 8px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 16px;
            width: 100%;
            box-sizing: border-box;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
        }

        .signoff-col {
            flex: 1;
            box-sizing: border-box;
        }

        .signoff-header {
            font-size: 9.5px;
            font-weight: 700;
            color: #000000;
            margin-bottom: 4px;
        }

        .signoff-lines {
            font-size: 9px;
            color: #000000;
            line-height: 1.4;
            white-space: nowrap;
            overflow: hidden;
        }

        /* --------------------------------------------------------------------------
           Print Optimizations & Media Queries
           -------------------------------------------------------------------------- */
        @media print {
            body {
                background: #ffffff !important;
                padding: 0 !important;
                margin: 0 !important;
            }

            .action-bar,
            .custom-filter-form,
            .shift-editable-input,
            .edit-hint-icon {
                display: none !important;
            }

            .print-val {
                display: inline-block !important;
            }

            .record-sheet {
                box-shadow: none !important;
                width: 100% !important;
                max-width: 100% !important;
                padding: 0 !important;
                margin: 0 !important;
            }

            @page {
                size: A4 portrait;
                margin: 10mm 10mm 10mm 10mm;
            }
        }
    </style>
</head>
<body>

    <!-- ACTION BAR (SCREEN ONLY) -->
    <div class="action-bar">
        <div class="filter-group">
            <span style="font-size: 11.5px; font-weight: 800; margin-right: 4px;">PERIOD:</span>
            <a href="export_sales_pdf.php?period=today" class="period-pill <?php echo $period === 'today' ? 'active' : ''; ?>">Today</a>
            <a href="export_sales_pdf.php?period=yesterday" class="period-pill <?php echo $period === 'yesterday' ? 'active' : ''; ?>">Yesterday</a>
            <a href="export_sales_pdf.php?period=week" class="period-pill <?php echo $period === 'week' ? 'active' : ''; ?>">Last 7 Days</a>
            <a href="export_sales_pdf.php?period=month" class="period-pill <?php echo $period === 'month' ? 'active' : ''; ?>">This Month</a>
            <a href="export_sales_pdf.php?period=all" class="period-pill <?php echo $period === 'all' ? 'active' : ''; ?>">All Records</a>
        </div>

        <div class="action-buttons">
            <button type="button" onclick="window.print()" class="btn-action">
                <i class="fa-solid fa-print"></i> Print Record
            </button>
            <button type="button" onclick="downloadPdfFile()" class="btn-action btn-dark">
                <i class="fa-solid fa-file-pdf"></i> Download PDF
            </button>
            <a href="sales_monitoring.php" class="btn-action">
                <i class="fa-solid fa-arrow-left"></i> Sales Monitoring
            </a>
        </div>
    </div>

    <form method="GET" action="export_sales_pdf.php" class="custom-filter-form">
        <input type="hidden" name="period" value="custom">
        <span>Custom Date Range:</span>
        <label>From: <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" required></label>
        <label>To: <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" required></label>
        <button type="submit" class="btn-filter-apply"><i class="fa-solid fa-filter"></i> Apply Range</button>
    </form>

    <!-- PRINTABLE RECORD OF SALES SHEET (EXACT BESKAPE REFERENCE FORMAT) -->
    <div class="record-sheet" id="printableRecord">
        
        <!-- TOP RUNNING HEADER -->
        <div class="running-header">
            <span>BesKape Coffee Roasters - Daily Sales Record</span>
            <span>Page 1 of 1</span>
        </div>

        <!-- MAIN HEADER -->
        <div class="doc-header-grid">
            <div class="header-left">
                <div class="brand-title">BESKAPE COFFEE</div>
                <div class="brand-title">ROASTERS</div>
                <div class="brand-division">Commercial Operations & Retail Division</div>
                <div class="brand-address">123 Main Street, Santa Rosa, Laguna</div>
                <div class="brand-tax-contact">VAT Reg. TIN: 000-123-456-000 | Contact: (049) 555-0142</div>
            </div>

            <div class="header-right">
                <div class="doc-main-title">RECORD OF</div>
                <div class="doc-main-title">SALES</div>
                <div class="meta-field first"><span class="meta-label">Record Date:</span> <?php echo $record_date_display; ?></div>
                <div class="meta-field"><span class="meta-label">Log ID:</span> <?php echo htmlspecialchars($log_id); ?></div>
            </div>
        </div>

        <!-- HEADER DIVIDER LINE -->
        <div class="header-divider-line"></div>

        <!-- CASHIER SHIFT ASSIGNMENT BOX -->
        <div class="shift-box">
            <div class="shift-col">
                <span class="shift-label">Cashier Name:</span>
                <input type="text" id="cashier_name_input" class="shift-editable-input" value="<?php echo htmlspecialchars($default_cashier); ?>" placeholder="Cashier Name" title="Click to edit Cashier Name">
                <i class="fa-solid fa-pen edit-hint-icon" onclick="document.getElementById('cashier_name_input').focus()"></i>
                <span class="shift-fill-line print-val" id="cashier_name_print"><?php echo htmlspecialchars($default_cashier); ?></span>
            </div>

            <div class="shift-col shift-check-group">
                <span class="shift-label">Shift:</span>
                <span class="shift-check-box" onclick="toggleShiftCheck('morning')">
                    <span class="shift-check-square" id="check_morning"></span> Morning
                </span>
                <span class="shift-check-box" onclick="toggleShiftCheck('evening')">
                    <span class="shift-check-square" id="check_evening"></span> Evening
                </span>
            </div>

            <div class="shift-col">
                <span class="shift-label">Starting Cash Float:</span>
                <span>₱</span>
                <input type="number" step="0.01" id="float_input" class="shift-editable-input float-width" value="0.00" placeholder="0.00" title="Click to edit Starting Cash Float">
                <i class="fa-solid fa-pen edit-hint-icon" onclick="document.getElementById('float_input').focus()"></i>
                <span class="shift-fill-line print-val" id="float_print">0.00</span>
            </div>
        </div>

        <!-- ITEM TRANSACTIONS TABLE -->
        <table class="transaction-table">
            <thead>
                <tr>
                    <th class="col-datetime">DATE /<br>TIME</th>
                    <th class="col-transno">TRANSACTION<br>#</th>
                    <th class="col-desc">ITEM DESCRIPTION</th>
                    <th class="col-qty">QTY</th>
                    <th class="col-unitprice">UNIT<br>PRICE</th>
                    <th class="col-method">PAYMENT<br>METHOD</th>
                    <th class="col-grandtotal">GRAND<br>TOTAL</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($transactions)): ?>
                    <?php foreach ($transactions as $t): ?>
                        <tr>
                            <td class="col-datetime"><?php echo date('M d, h:i A', strtotime($t['order_date'])); ?></td>
                            <td class="col-transno">REC-<?php echo str_pad($t['transaction_id'], 4, '0', STR_PAD_LEFT); ?></td>
                            <td class="col-desc"><?php echo htmlspecialchars($t['item_description']); ?></td>
                            <td class="col-qty"><?php echo $t['qty']; ?></td>
                            <td class="col-unitprice">₱<?php echo number_format($t['unit_price'], 2); ?></td>
                            <td class="col-method">Cash</td>
                            <td class="col-grandtotal">₱<?php echo number_format($t['line_total'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="empty-table-cell">No sales transactions recorded for this period.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- RECONCILIATION & SUMMARY SECTION -->
        <div class="reconciliation-summary-grid">
            
            <!-- Left: Payment Method Reconciliation -->
            <div class="payment-recon-box">
                <div class="payment-recon-title">PAYMENT METHOD RECONCILIATION</div>
                
                <div class="recon-row">
                    <span>Cash Payments Collected:</span>
                    <span class="recon-amount" id="recon_cash_text">₱<?php echo number_format($grand_total, 2); ?></span>
                </div>
                <div class="recon-row">
                    <span>Credit / Debit Card:</span>
                    <span class="recon-amount">₱0.00</span>
                </div>
                <div class="recon-row">
                    <span>Digital E-Wallet (GCash/Maya):</span>
                    <span class="recon-amount">₱0.00</span>
                </div>
                <div class="recon-row">
                    <span>Bank Transfers:</span>
                    <span class="recon-amount">₱0.00</span>
                </div>
            </div>

            <!-- Right: Totals Summary -->
            <div class="summary-totals-block">
                <div class="summary-row">
                    <span>Total Qty Sold:</span>
                    <span class="summary-row-bold"><?php echo number_format($total_qty); ?> Qty</span>
                </div>
                <div class="summary-row">
                    <span>Value Added Tax (12% VAT):</span>
                    <span class="summary-row-bold">₱<?php echo number_format($vat_12, 2); ?></span>
                </div>
                <div class="summary-row">
                    <span>Net Sales (Excl. VAT):</span>
                    <span class="summary-row-bold">₱<?php echo number_format($net_sales, 2); ?></span>
                </div>
                
                <div class="summary-rule"></div>
                
                <div class="revenue-row">
                    <span>Grand Total Revenue:</span>
                    <span>₱<?php echo number_format($grand_total, 2); ?></span>
                </div>
            </div>

        </div>

        <!-- SIGN-OFF FOOTER -->
        <div class="signoff-section">
            <div class="signoff-col">
                <div class="signoff-header">Cashier Signature (Start of Shift)</div>
                <div class="signoff-lines">
                    Time In: _________ &nbsp;|&nbsp; Signature: _____________
                </div>
            </div>

            <div class="signoff-col">
                <div class="signoff-header">Cashier Signature & Drawer Handover (End of Shift)</div>
                <div class="signoff-lines">
                    Ending Cash Count: ₱ _______ &nbsp;|&nbsp; Manager Sign-off: _______
                </div>
            </div>
        </div>

    </div>

    <script>
        // Interactive Shift Toggle Checkbox
        function toggleShiftCheck(shiftType) {
            const m = document.getElementById('check_morning');
            const e = document.getElementById('check_evening');
            if (shiftType === 'morning') {
                m.innerText = m.innerText === '✓' ? '' : '✓';
                e.innerText = '';
            } else {
                e.innerText = e.innerText === '✓' ? '' : '✓';
                m.innerText = '';
            }
        }

        // Synchronize Cashier Name and Starting Cash Float for Print and PDF
        function syncPrintValues() {
            const cInput = document.getElementById('cashier_name_input');
            const fInput = document.getElementById('float_input');
            const cPrint = document.getElementById('cashier_name_print');
            const fPrint = document.getElementById('float_print');

            if (cInput && cPrint) {
                const val = cInput.value.trim();
                cPrint.innerText = val ? val : '______________________';
            }

            if (fInput && fPrint) {
                const val = fInput.value.trim();
                const num = parseFloat(val);
                fPrint.innerText = (!isNaN(num) && num >= 0) ? num.toFixed(2) : '0.00';
            }
        }

        // Live input listeners
        document.getElementById('cashier_name_input').addEventListener('input', syncPrintValues);
        document.getElementById('float_input').addEventListener('input', syncPrintValues);

        window.addEventListener('beforeprint', syncPrintValues);

        // Download Exact Formal PDF using html2pdf.js with pre-synchronized values
        function downloadPdfFile() {
            window.scrollTo(0, 0);
            syncPrintValues();

            const cInput = document.getElementById('cashier_name_input');
            const fInput = document.getElementById('float_input');
            const cPrint = document.getElementById('cashier_name_print');
            const fPrint = document.getElementById('float_print');
            const icons = document.querySelectorAll('.edit-hint-icon');

            // Switch to print display for clean high-res canvas snapshot
            if (cInput) cInput.style.display = 'none';
            if (fInput) fInput.style.display = 'none';
            if (cPrint) cPrint.style.display = 'inline-block';
            if (fPrint) fPrint.style.display = 'inline-block';
            icons.forEach(ic => ic.style.display = 'none');

            const element = document.getElementById('printableRecord');

            const opt = {
                margin:       [8, 8, 8, 8],
                filename:     'Formal_Daily_Sales_Record_BesKape_<?php echo date("Ymd"); ?>.pdf',
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { 
                    scale: 2, 
                    useCORS: true, 
                    letterRendering: true, 
                    backgroundColor: '#ffffff'
                },
                jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' },
                pagebreak:    { mode: ['avoid-all', 'css', 'legacy'] }
            };

            html2pdf().from(element).set(opt).save().catch(err => {
                console.error("PDF download error:", err);
                window.print();
            }).finally(() => {
                // Restore interactive input fields
                if (cInput) cInput.style.display = 'inline-block';
                if (fInput) fInput.style.display = 'inline-block';
                if (cPrint) cPrint.style.display = 'none';
                if (fPrint) fPrint.style.display = 'none';
                icons.forEach(ic => ic.style.display = 'inline-block');
            });
        }

        // Auto-action if triggered from pull-out modal query params
        window.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('download') === '1') {
                setTimeout(downloadPdfFile, 600);
            } else if (urlParams.get('print') === '1') {
                setTimeout(() => window.print(), 600);
            }
        });
    </script>

</body>
</html>
