<?php
// Database Configuration
// On localhost (XAMPP): host is "localhost", user is "root", pass is "", dbname is "smartcafe_fvz"
// On InfinityFree: update with MySQL Host, Username, Password, and Database Name from your vPanel
$host = getenv('DB_HOST') ?: "localhost";
$user = getenv('DB_USER') ?: "root";
$pass = getenv('DB_PASS') !== false ? getenv('DB_PASS') : "";
$dbname = getenv('DB_NAME') ?: "smartcafe_fvz";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("<div style='font-family:Segoe UI,sans-serif; max-width:600px; margin:40px auto; padding:24px; background:#fff1f2; border:1.5px solid #fecdd3; border-radius:12px; color:#9f1239; box-shadow:0 10px 25px rgba(0,0,0,0.05);'>
        <h3 style='margin:0 0 10px 0; color:#881337;'>SmartCafe: Database Connection Error</h3>
        <p style='margin:0 0 12px 0; font-size:14px; line-height:1.5;'>Could not connect to the database <strong>" . htmlspecialchars($dbname) . "</strong> on <strong>" . htmlspecialchars($host) . "</strong>.</p>
        <p style='margin:0 0 12px 0; font-size:13px; color:#4c0519;'>Please check your MySQL details inside <code>config.php</code> (Host, Username, Password, and Database Name).</p>
        <pre style='background:#ffffff; padding:10px 14px; border-radius:8px; border:1px solid #fecdd3; font-size:12px; overflow-x:auto; margin:0;'>" . htmlspecialchars(mysqli_connect_error()) . "</pre>
    </div>");
}

mysqli_set_charset($conn, "utf8mb4");
?>