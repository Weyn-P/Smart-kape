<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config.php';

// Access Control: Only logged-in users with valid roles can access
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Handle AJAX Save for Physical Audit Counts and Costs
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_physical_inventory') {
    header('Content-Type: application/json');
    if (!isset($_POST['items']) || !is_array($_POST['items'])) {
        echo json_encode(['success' => false, 'message' => 'No items provided']);
        exit();
    }

    $stmt = $conn->prepare("UPDATE inventory SET quantity = ?, unit_cost = ? WHERE id = ?");
    $updated_count = 0;
    foreach ($_POST['items'] as $item) {
        $id = (int)$item['id'];
        $count = (float)$item['physical_count'];
        $cost = (float)$item['unit_cost'];
        $stmt->bind_param("ddi", $count, $cost, $id);
        if ($stmt->execute()) {
            $updated_count++;
        }
    }
    $stmt->close();
    echo json_encode(['success' => true, 'updated' => $updated_count]);
    exit();
}

// Parameters
$filter = isset($_GET['filter']) ? trim($_GET['filter']) : 'all';
$auditor_default = isset($_SESSION['username']) ? $_SESSION['username'] : 'Inventory Auditor';

// Category Label and Query based on filter
if ($filter === 'low_stock') {
    $sql = "SELECT * FROM inventory WHERE quantity <= min_threshold ORDER BY item_name ASC";
    $category_label = "Low Stock & Reorder Alerts";
} elseif ($filter === 'Ingredients') {
    $sql = "SELECT * FROM inventory WHERE category IN ('Coffee', 'Dairy', 'Syrup', 'Sauce') ORDER BY category ASC, item_name ASC";
    $category_label = "Ingredients (Coffee, Dairy, Syrups & Sauces)";
} elseif ($filter === 'Packaging') {
    $sql = "SELECT * FROM inventory WHERE category LIKE '%Packaging%' ORDER BY item_name ASC";
    $category_label = "Packaging (Cups, Lids & Retail Supplies)";
} elseif ($filter === 'Merch') {
    $sql = "SELECT * FROM inventory WHERE category LIKE '%Merch%' OR category LIKE '%Other%' ORDER BY item_name ASC";
    $category_label = "Merch & Store Materials";
} elseif ($filter === 'Dairy') {
    $sql = "SELECT * FROM inventory WHERE category LIKE '%Dairy%' ORDER BY item_name ASC";
    $category_label = "Dairy & Milk";
} elseif ($filter === 'Coffee') {
    $sql = "SELECT * FROM inventory WHERE category LIKE '%Coffee%' ORDER BY item_name ASC";
    $category_label = "Raw Coffee Beans";
} elseif ($filter === 'Syrup') {
    $sql = "SELECT * FROM inventory WHERE (category LIKE '%Syrup%' OR category LIKE '%Sauce%') ORDER BY item_name ASC";
    $category_label = "Syrups & Flavoring";
} else {
    $sql = "SELECT * FROM inventory ORDER BY category ASC, item_name ASC";
    $category_label = "All Categories (Complete Physical Count)";
}

$result = mysqli_query($conn, $sql);
$items = [];
$total_items = 0;
$total_physical_qty = 0.0;
$grand_total_valuation = 0.0;

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $count = (float)$row['quantity'];
        $cost = isset($row['unit_cost']) ? (float)$row['unit_cost'] : 0.0;
        $valuation = $count * $cost;

        $total_items++;
        $total_physical_qty += $count;
        $grand_total_valuation += $valuation;

        // Clean unit formatting
        $unit = strtolower(trim($row['unit']));
        if ($unit === 'bottle' || $unit === 'bottles') $unit_str = 'bottles';
        elseif ($unit === 'pack' || $unit === 'packs') $unit_str = 'packs';
        elseif ($unit === 'box' || $unit === 'boxes') $unit_str = 'boxes';
        elseif ($unit === 'carton' || $unit === 'cartons') $unit_str = 'liters';
        elseif ($unit === 'kg') $unit_str = 'kg';
        else $unit_str = $unit;

        $items[] = [
            'id' => $row['id'],
            'item_code' => sprintf("INV-%03d", $row['id']),
            'item_name' => $row['item_name'],
            'category' => $row['category'],
            'unit' => $unit_str,
            'physical_count' => $count,
            'unit_cost' => $cost,
            'total_valuation' => $valuation
        ];
    }
}

$log_id = 'INV-' . date('Y-md');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Physical Record of Inventory - BesKape Coffee Roasters Co.</title>
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts: Times/Cinzel Serif and Inter Sans -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700;800;900&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- html2pdf.js library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js"></script>

    <style>
        /* --------------------------------------------------------------------------
           Screen Action Bar & Wrapper
           -------------------------------------------------------------------------- */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: #525659;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            color: #000000;
            padding: 24px 16px;
            margin: 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .action-bar {
            max-width: 820px;
            margin: 0 auto 16px auto;
            background: #ffffff;
            border-radius: 12px;
            padding: 12px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.25);
            flex-wrap: wrap;
            gap: 12px;
        }

        .filter-group {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }

        .filter-group .period-label {
            font-size: 11px;
            font-weight: 800;
            margin-right: 4px;
            color: #1e293b;
            letter-spacing: 0.05em;
        }

        .period-pill {
            font-size: 11px;
            padding: 5px 10px;
            border-radius: 8px;
            text-decoration: none;
            color: #334155;
            background: #f1f5f9;
            font-weight: 600;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            border: 1px solid #cbd5e1;
        }

        .period-pill:hover {
            background: #e2e8f0;
            color: #0f172a;
        }

        .period-pill.active {
            background: #000000;
            color: #ffffff;
            border-color: #000000;
            font-weight: 700;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
        }

        .btn-action {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 13px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            border: 1px solid #cbd5e1;
            background: #ffffff;
            color: #1e293b;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .btn-action:hover {
            background: #f1f5f9;
            border-color: #94a3b8;
        }

        .btn-action.btn-dark {
            background: #000000;
            color: #ffffff;
            border-color: #000000;
        }

        .btn-action.btn-dark:hover {
            background: #262626;
        }

        .btn-action.btn-save {
            background: #059669;
            color: #ffffff;
            border-color: #059669;
        }

        .btn-action.btn-save:hover {
            background: #047857;
        }

        .screen-notice {
            max-width: 820px;
            margin: 0 auto 12px auto;
            background: #ffffff;
            border: 1px solid #000000;
            color: #000000;
            padding: 8px 14px;
            border-radius: 8px;
            font-size: 11.5px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        /* --------------------------------------------------------------------------
           Formal Monochrome (All-Black) Document Sheet
           -------------------------------------------------------------------------- */
        .record-sheet {
            background: #ffffff;
            width: 100%;
            max-width: 820px;
            margin: 0 auto;
            padding: 28px 32px;
            box-shadow: 0 8px 28px rgba(0, 0, 0, 0.35);
            font-size: 9.5px;
            line-height: 1.35;
            color: #000000;
            box-sizing: border-box;
        }

        /* Running Top Header */
        .running-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 8.5px;
            font-weight: 700;
            color: #000000;
            border-bottom: 1px solid #000000;
            padding-bottom: 4px;
            margin-bottom: 12px;
            letter-spacing: 0.02em;
        }

        /* Main Header Grid */
        .doc-header-grid {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }

        .header-left {
            max-width: 480px;
        }

        .brand-title {
            font-family: 'Cinzel', 'Times New Roman', Georgia, serif;
            font-size: 20px;
            font-weight: 900;
            line-height: 1.1;
            letter-spacing: 0.03em;
            color: #000000;
        }

        .brand-division {
            font-size: 9.5px;
            font-weight: 700;
            margin-top: 4px;
            color: #000000;
        }

        .brand-tax-contact {
            font-size: 8.5px;
            font-weight: 500;
            margin-top: 1px;
            color: #000000;
        }

        .header-right {
            text-align: right;
            min-width: 250px;
        }

        .doc-title-main {
            font-family: 'Cinzel', 'Times New Roman', Georgia, serif;
            font-size: 16px;
            font-weight: 900;
            line-height: 1.2;
            letter-spacing: 0.03em;
            color: #000000;
            margin-bottom: 4px;
        }

        .meta-line {
            font-size: 9px;
            font-weight: 700;
            color: #000000;
            line-height: 1.4;
        }

        /* Solid Divider Rule */
        .divider-rule {
            border-top: 2px solid #000000;
            margin: 8px 0 10px 0;
        }

        /* Fillable Administrative Metadata Box (All-Black Monochrome) */
        .admin-meta-box {
            border: 1.5px solid #000000;
            padding: 8px 12px;
            margin-bottom: 12px;
            display: grid;
            grid-template-columns: 1.3fr 1fr;
            gap: 6px 16px;
            font-size: 9.5px;
            background: #ffffff;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
        }

        .meta-label {
            font-weight: 800;
            color: #000000;
            text-transform: uppercase;
            font-size: 9px;
            letter-spacing: 0.02em;
        }

        .meta-value-fixed {
            font-weight: 700;
            color: #000000;
        }

        .meta-input-inline {
            border: 1px dashed #000000;
            background: #ffffff;
            font-family: inherit;
            font-size: 9.5px;
            font-weight: 700;
            padding: 2px 6px;
            color: #000000;
            outline: none;
            flex: 1;
        }

        .meta-input-inline:focus {
            border-style: solid;
        }

        .print-val {
            display: none;
            font-weight: 700;
            color: #000000;
        }

        /* --------------------------------------------------------------------------
           Inventory Count Table (Clean, Formal, All-Black Monochrome, No Color Fills)
           -------------------------------------------------------------------------- */
        .count-table-wrap {
            width: 100%;
            margin-bottom: 12px;
        }

        .inventory-count-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 9.5px;
            color: #000000;
            background: #ffffff;
        }

        .inventory-count-table thead th {
            border-top: 1.5px solid #000000;
            border-bottom: 1.5px solid #000000;
            padding: 7px 6px;
            font-weight: 900;
            letter-spacing: 0.03em;
            text-transform: uppercase;
            font-size: 9px;
            color: #000000;
            background: #ffffff !important;
            vertical-align: middle;
        }

        .inventory-count-table tbody td {
            padding: 6px 6px;
            border-bottom: 1px solid #000000;
            vertical-align: middle;
            font-size: 9.5px;
            background: #ffffff !important;
        }

        .inventory-count-table tbody tr:last-child td {
            border-bottom: 1.5px solid #000000;
        }

        /* Column Specific Alignments & Widths (6 Exact Columns) */
        .col-desc { text-align: left; width: 32%; font-weight: 700; }
        .col-cat { text-align: left; width: 20%; color: #000000; }
        .col-count { text-align: right; width: 14%; font-variant-numeric: tabular-nums; font-weight: 800; }
        .col-unit { text-align: center; width: 10%; }
        .col-cost { text-align: right; width: 11%; font-variant-numeric: tabular-nums; }
        .col-valuation { text-align: right; width: 13%; font-weight: 800; font-variant-numeric: tabular-nums; }

        /* Editable inputs on screen */
        .qty-input {
            width: 58px;
            padding: 2px 4px;
            border: 1px dashed #000000;
            background: #ffffff;
            text-align: right;
            font-size: 9.5px;
            font-weight: 700;
            color: #000000;
            font-family: inherit;
        }

        .cost-input {
            width: 62px;
            padding: 2px 4px;
            border: 1px dashed #000000;
            background: #ffffff;
            text-align: right;
            font-size: 9.5px;
            font-weight: 700;
            color: #000000;
            font-family: inherit;
        }

        .qty-input:focus, .cost-input:focus {
            border-style: solid;
            outline: none;
        }

        .qty-print-val, .cost-print-val {
            display: none;
        }

        /* --------------------------------------------------------------------------
           Summary & Sign-Off Section (All-Black Monochrome)
           -------------------------------------------------------------------------- */
        .summary-signoff-wrap {
            page-break-inside: avoid;
            break-inside: avoid;
        }

        .bottom-summary-grid {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 14px;
            gap: 16px;
        }

        /* Left: Inventory Summary Box */
        .health-summary-box {
            border: 1.5px solid #000000;
            padding: 8px 12px;
            width: 360px;
            box-sizing: border-box;
            background: #ffffff;
        }

        .health-title {
            font-weight: 900;
            font-size: 9.5px;
            letter-spacing: 0.03em;
            text-transform: uppercase;
            border-bottom: 1px solid #000000;
            padding-bottom: 4px;
            margin-bottom: 6px;
        }

        .health-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 9.5px;
            padding: 2px 0;
        }

        .health-row-label {
            font-weight: 600;
        }

        .health-row-val {
            font-weight: 800;
            font-variant-numeric: tabular-nums;
        }

        /* Right: Valuation Metric Block */
        .metrics-block {
            width: 340px;
            margin-left: auto;
            box-sizing: border-box;
        }

        .metric-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 9.5px;
            padding: 2.5px 0;
        }

        .metric-row-label {
            font-weight: 600;
        }

        .metric-row-val {
            font-weight: 800;
            font-variant-numeric: tabular-nums;
        }

        .metric-rule {
            border-top: 1px solid #000000;
            margin: 4px 0;
        }

        .grand-valuation-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 12.5px;
            font-weight: 900;
            padding: 4px 0;
            border-bottom: 3px double #000000;
        }

        /* Formal Sign-Off Handover Block */
        .signoff-section {
            border-top: 1.5px solid #000000;
            padding-top: 8px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 24px;
            width: 100%;
            box-sizing: border-box;
        }

        .signoff-col {
            flex: 1;
            box-sizing: border-box;
        }

        .signoff-header {
            font-size: 9px;
            font-weight: 900;
            color: #000000;
            margin-bottom: 6px;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        .signoff-lines {
            font-size: 8.5px;
            color: #000000;
            line-height: 1.6;
            white-space: nowrap;
        }

        /* --------------------------------------------------------------------------
           Print Optimizations
           -------------------------------------------------------------------------- */
        @media print {
            body {
                background: #ffffff !important;
                padding: 0 !important;
                margin: 0 !important;
            }

            .action-bar,
            .screen-notice,
            .meta-input-inline,
            .qty-input,
            .cost-input {
                display: none !important;
            }

            .print-val,
            .qty-print-val,
            .cost-print-val {
                display: inline-block !important;
            }

            .record-sheet {
                box-shadow: none !important;
                width: 100% !important;
                max-width: 100% !important;
                padding: 0 !important;
                margin: 0 !important;
                border: none !important;
            }

            @page {
                size: A4 portrait;
                margin: 10mm 10mm 10mm 10mm;
            }
        }
    </style>
</head>
<body>

    <!-- SCREEN ACTION BAR -->
    <div class="action-bar">
        <div class="filter-group">
            <span class="period-label">CATEGORY FILTER:</span>
            <a href="export_inventory_pdf.php?filter=all" class="period-pill <?php echo $filter === 'all' ? 'active' : ''; ?>">All Categories</a>
            <a href="export_inventory_pdf.php?filter=Ingredients" class="period-pill <?php echo $filter === 'Ingredients' ? 'active' : ''; ?>">Ingredients</a>
            <a href="export_inventory_pdf.php?filter=Packaging" class="period-pill <?php echo $filter === 'Packaging' ? 'active' : ''; ?>">Packaging</a>
            <a href="export_inventory_pdf.php?filter=low_stock" class="period-pill <?php echo $filter === 'low_stock' ? 'active' : ''; ?>">Low Stock Alerts</a>
        </div>

        <div class="action-buttons">
            <button type="button" onclick="window.print()" class="btn-action">
                <i class="fa-solid fa-print"></i> Print Record
            </button>
            <button type="button" onclick="downloadPdfFile()" class="btn-action btn-dark">
                <i class="fa-solid fa-file-pdf"></i> Download PDF
            </button>
            <a href="inventory_management.php" class="btn-action">
                <i class="fa-solid fa-arrow-left"></i> Inventory Management
            </a>
        </div>
    </div>

    <!-- PRINTABLE PHYSICAL RECORD OF INVENTORY SHEET -->
    <div class="record-sheet" id="printableRecord">
        
        <!-- RUNNING HEADER -->
        <div class="running-header">
            <span>BesKape Coffee Roasters Co. - Physical Record of Inventory</span>
            <span>Page 1 of 1</span>
        </div>

        <!-- MAIN HEADER -->
        <div class="doc-header-grid">
            <div class="header-left">
                <div class="brand-title">BesKape Coffee Roasters Co.</div>
                <div class="brand-division">Commercial Operations & Inventory Control • Santa Rosa, Laguna</div>
                <div class="brand-tax-contact">VAT Reg. TIN: 000-123-456-000 | Contact: (049) 555-0142</div>
            </div>

            <div class="header-right">
                <div class="doc-title-main">PHYSICAL RECORD OF</div>
                <div class="doc-title-main">INVENTORY</div>
                <div class="meta-line">Audit Date: <?php echo date('F d, Y'); ?></div>
                <div class="meta-line">Log ID: <?php echo htmlspecialchars($log_id); ?></div>
            </div>
        </div>

        <div class="divider-rule"></div>

        <!-- FILLABLE ADMINISTRATIVE METADATA FIELDS (WITH FIXED LOCATION) -->
        <div class="admin-meta-box">
            <div class="meta-item">
                <span class="meta-label">Location / Branch:</span>
                <span class="meta-value-fixed">Main Branch - Santa Rosa, Laguna</span>
            </div>

            <div class="meta-item">
                <span class="meta-label">Date:</span>
                <span id="date_print" class="print-val"><?php echo date('F d, Y'); ?></span>
                <input type="text" id="date_input" value="<?php echo date('F d, Y'); ?>" class="meta-input-inline" placeholder="Date">
            </div>

            <div class="meta-item">
                <span class="meta-label">Category:</span>
                <span id="cat_print" class="print-val"><?php echo htmlspecialchars($category_label); ?></span>
                <input type="text" id="cat_input" value="<?php echo htmlspecialchars($category_label); ?>" class="meta-input-inline" placeholder="Category (e.g., Ingredients, Packaging)">
            </div>

            <div class="meta-item">
                <span class="meta-label">Counted By:</span>
                <span id="auditor_print" class="print-val"><?php echo htmlspecialchars($auditor_default); ?></span>
                <input type="text" id="auditor_input" value="<?php echo htmlspecialchars($auditor_default); ?>" class="meta-input-inline" placeholder="Counted By (Name/Signature)">
            </div>
        </div>

        <!-- INVENTORY COUNT TABLE (EXACT 6 SPECIFIED COLUMNS, MONOCHROME) -->
        <div class="count-table-wrap">
            <table class="inventory-count-table">
                <thead>
                    <tr>
                        <th class="col-desc">Item Description</th>
                        <th class="col-cat">Category</th>
                        <th class="col-count">Physical Count / On-Hand</th>
                        <th class="col-unit">Unit of Measure</th>
                        <th class="col-cost">Unit Cost</th>
                        <th class="col-valuation">Total Valuation</th>
                    </tr>
                </thead>
                <tbody id="inventoryTableBody">
                    <?php if (!empty($items)): ?>
                        <?php foreach ($items as $idx => $it): ?>
                            <tr class="item-row" data-id="<?php echo $it['id']; ?>">
                                <td class="col-desc"><?php echo htmlspecialchars($it['item_name']); ?></td>
                                <td class="col-cat"><?php echo htmlspecialchars($it['category']); ?></td>
                                <td class="col-count">
                                    <span class="qty-print-val val-count-print"><?php echo number_format($it['physical_count'], 1); ?> Qty</span>
                                    <span class="qty-screen-edit">
                                        <input type="number" step="0.5" min="0" class="qty-input input-count" value="<?php echo number_format($it['physical_count'], 1, '.', ''); ?>" oninput="recalcRow(this)"> Qty
                                    </span>
                                </td>
                                <td class="col-unit"><?php echo htmlspecialchars($it['unit']); ?></td>
                                <td class="col-cost">
                                    <span class="cost-print-val val-cost-print">₱<?php echo number_format($it['unit_cost'], 2); ?></span>
                                    <span class="cost-screen-edit">
                                        ₱<input type="number" step="1.00" min="0" class="cost-input input-cost" value="<?php echo number_format($it['unit_cost'], 2, '.', ''); ?>" oninput="recalcRow(this)">
                                    </span>
                                </td>
                                <td class="col-valuation">
                                    ₱<span class="val-valuation"><?php echo number_format($it['total_valuation'], 2); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 25px; color: #000000; font-style: italic;">
                                No inventory items found under the selected category.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- INVENTORY SUMMARY & SIGN-OFF (ALL-BLACK MONOCHROME) -->
        <div class="summary-signoff-wrap">
            <div class="bottom-summary-grid">
                
                <!-- LEFT: INVENTORY SUMMARY & TRACKED METRICS -->
                <div class="health-summary-box">
                    <div class="health-title">Inventory Count Summary</div>
                    <div class="health-row">
                        <span class="health-row-label">Total Items Counted:</span>
                        <span class="health-row-val"><span id="totalItemsCount"><?php echo $total_items; ?></span> Items</span>
                    </div>
                    <div class="health-row">
                        <span class="health-row-label">Total Physical Quantity On-Hand:</span>
                        <span class="health-row-val"><span id="totalPhysicalQty"><?php echo number_format($total_physical_qty, 1); ?></span> Qty</span>
                    </div>
                    <div class="health-row">
                        <span class="health-row-label">Physical Count Audit Status:</span>
                        <span class="health-row-val">Completed & Reconciled</span>
                    </div>
                </div>

                <!-- RIGHT: TOTAL INVENTORY VALUATION (GRAND TOTAL) -->
                <div class="metrics-block">
                    <div class="metric-row">
                        <span class="metric-row-label">Estimated Store Inventory Value:</span>
                        <span class="metric-row-val">₱<span id="subtotalValuation"><?php echo number_format($grand_total_valuation, 2); ?></span></span>
                    </div>
                    <div class="metric-rule"></div>
                    <div class="grand-valuation-row">
                        <span>Total Inventory Valuation:</span>
                        <span>₱<span id="grandTotalValuation"><?php echo number_format($grand_total_valuation, 2); ?></span></span>
                    </div>
                </div>
            </div>

            <!-- END-OF-PERIOD PHYSICAL AUDIT SIGN-OFF BLOCK FOR AUDITOR & MANAGER -->
            <div class="signoff-section">
                <div class="signoff-col">
                    <div class="signoff-header">Inventory Auditor Sign-Off</div>
                    <div class="signoff-lines">
                        Print Name: ___________________________________<br>
                        Signature:  ___________________________________<br>
                        Date:       ___________________________________
                    </div>
                </div>

                <div class="signoff-col" style="text-align: right;">
                    <div class="signoff-header">Store Manager Verification & Approval</div>
                    <div class="signoff-lines">
                        Approved By: ___________________________________<br>
                        Signature:   ___________________________________<br>
                        Date:        ___________________________________
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- CLIENT LOGIC & REAL-TIME VALUATION RECALCULATION -->
    <script>
        function syncPrintValues() {
            const dateInput = document.getElementById('date_input');
            const datePrint = document.getElementById('date_print');
            if (dateInput && datePrint) {
                datePrint.innerText = dateInput.value.trim() || '<?php echo date("F d, Y"); ?>';
            }

            const catInput = document.getElementById('cat_input');
            const catPrint = document.getElementById('cat_print');
            if (catInput && catPrint) {
                catPrint.innerText = catInput.value.trim() || '<?php echo htmlspecialchars($category_label); ?>';
            }

            const auditorInput = document.getElementById('auditor_input');
            const auditorPrint = document.getElementById('auditor_print');
            if (auditorInput && auditorPrint) {
                auditorPrint.innerText = auditorInput.value.trim() || '______________________';
            }

            document.querySelectorAll('#inventoryTableBody .item-row').forEach(row => {
                const countInput = row.querySelector('.input-count');
                const costInput = row.querySelector('.input-cost');

                const countPrint = row.querySelector('.val-count-print');
                const costPrint = row.querySelector('.val-cost-print');

                if (countInput && countPrint) {
                    countPrint.innerText = (parseFloat(countInput.value) || 0).toFixed(1) + ' Qty';
                }
                if (costInput && costPrint) {
                    costPrint.innerText = '₱' + (parseFloat(costInput.value) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                }
            });
        }

        function recalcRow(el) {
            const row = el.closest('.item-row');
            if (!row) return;

            const count = parseFloat(row.querySelector('.input-count').value) || 0;
            const cost = parseFloat(row.querySelector('.input-cost').value) || 0;
            const valuation = count * cost;

            row.querySelector('.val-valuation').innerText = valuation.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

            recalcAllTotals();
            syncPrintValues();
        }

        function recalcAllTotals() {
            let sumQty = 0.0;
            let grandValuation = 0.0;
            let totalRows = 0;

            document.querySelectorAll('#inventoryTableBody .item-row').forEach(row => {
                totalRows++;
                const count = parseFloat(row.querySelector('.input-count').value) || 0;
                const cost = parseFloat(row.querySelector('.input-cost').value) || 0;
                const valuation = count * cost;

                sumQty += count;
                grandValuation += valuation;
            });

            document.getElementById('totalItemsCount').innerText = totalRows;
            document.getElementById('totalPhysicalQty').innerText = sumQty.toFixed(1);
            const formattedGrand = grandValuation.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            document.getElementById('subtotalValuation').innerText = formattedGrand;
            document.getElementById('grandTotalValuation').innerText = formattedGrand;
        }

        document.getElementById('date_input').addEventListener('input', syncPrintValues);
        document.getElementById('cat_input').addEventListener('input', syncPrintValues);
        document.getElementById('auditor_input').addEventListener('input', syncPrintValues);
        window.addEventListener('beforeprint', syncPrintValues);

        // Download Exact Monochrome PDF
        function downloadPdfFile() {
            window.scrollTo(0, 0);
            syncPrintValues();

            const dateInput = document.getElementById('date_input');
            const catInput = document.getElementById('cat_input');
            const auditorInput = document.getElementById('auditor_input');

            const datePrint = document.getElementById('date_print');
            const catPrint = document.getElementById('cat_print');
            const auditorPrint = document.getElementById('auditor_print');

            if (dateInput) dateInput.style.display = 'none';
            if (catInput) catInput.style.display = 'none';
            if (auditorInput) auditorInput.style.display = 'none';

            if (datePrint) datePrint.style.display = 'inline-block';
            if (catPrint) catPrint.style.display = 'inline-block';
            if (auditorPrint) auditorPrint.style.display = 'inline-block';

            const qtyEdits = document.querySelectorAll('.qty-screen-edit');
            const costEdits = document.querySelectorAll('.cost-screen-edit');
            const qtyPrints = document.querySelectorAll('.qty-print-val');
            const costPrints = document.querySelectorAll('.cost-print-val');

            qtyEdits.forEach(i => i.style.display = 'none');
            costEdits.forEach(i => i.style.display = 'none');
            qtyPrints.forEach(p => p.style.display = 'inline-block');
            costPrints.forEach(p => p.style.display = 'inline-block');

            const element = document.getElementById('printableRecord');

            const opt = {
                margin:       [8, 8, 8, 8],
                filename:     'Physical_Record_of_Inventory_BesKape_<?php echo date("Ymd"); ?>.pdf',
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { 
                    scale: 2, 
                    useCORS: true, 
                    letterRendering: true, 
                    backgroundColor: '#ffffff'
                },
                jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' },
                pagebreak:    { mode: ['avoid-all', 'css', 'legacy'] }
            };

            html2pdf().from(element).set(opt).save().catch(err => {
                console.error("PDF download error:", err);
                window.print();
            }).finally(() => {
                if (dateInput) dateInput.style.display = 'inline-block';
                if (catInput) catInput.style.display = 'inline-block';
                if (auditorInput) auditorInput.style.display = 'inline-block';

                if (datePrint) datePrint.style.display = 'none';
                if (catPrint) catPrint.style.display = 'none';
                if (auditorPrint) auditorPrint.style.display = 'none';

                qtyEdits.forEach(i => i.style.display = 'inline-block');
                costEdits.forEach(i => i.style.display = 'inline-block');
                qtyPrints.forEach(p => p.style.display = 'none');
                costPrints.forEach(p => p.style.display = 'none');
            });
        }

        // Save Adjustments to Database
        function saveAuditValuations() {
            const items = [];
            document.querySelectorAll('#inventoryTableBody .item-row').forEach(row => {
                const id = row.getAttribute('data-id');
                const count = parseFloat(row.querySelector('.input-count').value) || 0;
                const cost = parseFloat(row.querySelector('.input-cost').value) || 0;
                items.push({ id, physical_count: count, unit_cost: cost });
            });

            const saveStatus = document.getElementById('saveStatus');
            saveStatus.innerText = 'Saving changes...';

            const formData = new FormData();
            formData.append('action', 'save_physical_inventory');
            items.forEach((item, index) => {
                formData.append(`items[${index}][id]`, item.id);
                formData.append(`items[${index}][physical_count]`, item.physical_count);
                formData.append(`items[${index}][unit_cost]`, item.unit_cost);
            });

            fetch('export_inventory_pdf.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    saveStatus.innerText = `✓ Successfully saved ${data.updated} inventory items!`;
                    setTimeout(() => { saveStatus.innerText = ''; }, 3500);
                } else {
                    saveStatus.innerText = 'Error: ' + (data.message || 'Failed to save');
                }
            })
            .catch(err => {
                console.error(err);
                saveStatus.innerText = 'Server error occurred while saving.';
            });
        }

        window.addEventListener('DOMContentLoaded', function() {
            syncPrintValues();
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('download') === '1') {
                setTimeout(downloadPdfFile, 600);
            } else if (urlParams.get('print') === '1') {
                setTimeout(() => window.print(), 600);
            }
        });
    </script>

</body>
</html>
